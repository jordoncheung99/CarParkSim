import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class FinalProjectMain extends PApplet {

float Base=0.001f;
 float base=Base;
 public void mouseClicked(){
   println(mouseX);
   println(mouseY);
    if((mouseX>50 && mouseX<60) && (mouseY>20 && mouseY<40)){
      Control.carSpawnFreq-=base;
    }
    if((mouseX>=140 && mouseX<=150) && (mouseY>=20 && mouseY<=40)){
      Control.carSpawnFreq+=base;
    }
    if((mouseX>=170 && mouseX<=180) && (mouseY>=20 && mouseY<=40)){
      Control.parkingFreq-=base;
    }
    if((mouseX>=260 && mouseX<=270) && (mouseY>=20 && mouseY<=40)){
      Control.parkingFreq+=base;
    }
    if((mouseX>=290 && mouseX<=300) && (mouseY>=20 && mouseY<=40)){
      Control.eventFreq-=base;
    }
    if((mouseX>=380 && mouseX<=390) && (mouseY>=20 && mouseY<=40)){
      Control.eventFreq+=base;
    }
    if((mouseX>=50 && mouseX<=60) && (mouseY>=60 && mouseY<=80)){
      Control.inBoundFreq-=base;
    }
    if((mouseX>=140 && mouseX<=150) && (mouseY>=60 && mouseY<=80)){
      Control.inBoundFreq+=base;
    }
    if((mouseX>=170 && mouseX<=180) && (mouseY>=60 && mouseY<=80)){
      Control.leaveFreq-=base;
    }
    if((mouseX>=260 && mouseX<=270) && (mouseY>=60 && mouseY<=80)){
      Control.leaveFreq+=base;
    }
    if((mouseX>=290 && mouseX<=300) && (mouseY>=60 && mouseY<=80)){
      Control.weatherFreq-=base;
    }
    if((mouseX>=380 && mouseX<=390) && (mouseY>=60 && mouseY<=80)){
      Control.weatherFreq+=base;
    }
    if((mouseX>=50 && mouseX<=60) && (mouseY>=100 && mouseY<=120)){
      Control.westBoundFreq-=base;
    }
    if((mouseX>=140 && mouseX<=150) && (mouseY>=100 && mouseY<=120)){
      Control.westBoundFreq+=base;
    }
    if((mouseX>=170 && mouseX<=180) && (mouseY>=100 && mouseY<=120)){
      Control.driftingFreq-=base;
    }
    if((mouseX>=260 && mouseX<=270) && (mouseY>=100 && mouseY<=120)){
      Control.driftingFreq+=base;
    }
    if((mouseX>630 && mouseX<730) && (mouseY>=25 && mouseY<=120)){
      Control.isPlay = !Control.isPlay;      
    }
   }
    public void keyPressed(){
      if(key=='z')
        base=Base*10;
      else if(key == 'x')
        base = Base*100;
      else
        base = Base;
      }
public void setup(){
  //Size of Screen
  
  // creates parking stall objects
  CDate  = new Date(0,1,0,true);
  Lot = new ParkingLot(260,220);
  Control = new Control();
  WStreet = new Street_2(0,150,"Textures/WStreet.png");
  EStreet = new Street_2(1100,150,"Textures/EStreet.png");
  Calc = new CostCalc();
  fil = new filters();
  fil.setAll();
  frameRate(60);
  
    engi = loadImage("Textures/Engi.png");
    window  = loadImage("Textures/Window.png");
    head = loadImage("Textures/HeadLights.png");
}
//settup for object and things such as that
  //Current Date = 0; and will add min every min
    Date CDate;
  //ParkingLot Initalization
    ParkingLot Lot;
  //Street
    Street_2 WStreet;
    Street_2 EStreet;
  //Control
    Control Control;
  //CostCalc
    CostCalc Calc;
  //filters like snow and things
    filters fil;
    ArrayList<Car> Cars = new ArrayList<Car>();
//What methods to run every run
public void run(){
  CDate.addMin();
  Lot.ParkingLotDraw();
  WStreet.StreetDraw();
  EStreet.StreetDraw();
  Lot.GateDraw();
  fil.curFill();
  Control.freqRun();
  drawCar();
}
public void draw(){
  if(!Control.isPlay){
  background(fil.backR,fil.backG,fil.backB);
  run();
  stroke(255);
  } 
  Control.ControlDraw();
}
 public void keyReleased(){
    if(key == 'p'){
      Control.isPlay = !Control.isPlay;
    }
 }
 public void drawCar(){
   for(int x = 0; x < Cars.size()-1; x++){
     pushMatrix();
     Cars.get(x).allMovement();
     Cars.get(x).draw_car();
     popMatrix();
     if(Cars.get(x).mc.py > 1100 || Cars.get(x).mc.py < -200){
       Cars.remove(x);
     }
     if(Cars.get(x).parked()){
       int s= Cars.get(x).lstall;
       int sx = s%5;
       int sy = s/5;
       int S = Cars.get(x).lsection;
       int Sx = S%3;
       int Sy = S/3;
       if(!Lot.PS[Sx][Sy].ps[sx][sy].saved&&!Cars.get(x).leaving){
       Lot.PS[Sx][Sy].ps[sx][sy].saved = true;
       Lot.PS[Sx][Sy].ps[sx][sy].setStatus(true,CDate);
       }
     }
   }
 }
 
 
   PImage head;
  PImage window;
  PImage engi;
class Car {
  movement_data mc;
  colour cc =new colour(random(255), random(255), random(255));
  float s=0.08f;
  boolean draw=true;
  boolean top;
  boolean bottom;
  boolean park;
  boolean lleft;
  boolean linbound= true;
  boolean leaving=false;
  boolean stopped=false;
  int lsection;
  int lstall;
  int adj_section;
  int adj_stall;
  //constructor
  Car(boolean left, boolean parking, boolean inbound, int section, int stall) {
    adj_section=section;
    if (adj_section>2) {
      adj_section-=3;
    }
    adj_stall=stall;
    if (adj_stall>4) {
      adj_stall-=5;
    }
    float positionx=300;
    float positiony=300;
    float da=0;
    float fa=0;
    park=parking;
    lleft=left;
    linbound=inbound;
    lsection=section;
    lstall=stall;
    //pathing in constructor
   
    if ((section==0 || section==1 || section==2) && (stall==0 || stall==1 || stall==2 || stall==3 || stall==4)) {
      top=true;
    }
    if ((section==3 || section==4 || section==5) && (stall==5 || stall==6 || stall==7 || stall==8 || stall==9)) {
      bottom=true;
    }
    //staring paths
    if (left==true && linbound==false) {
      positionx=130;
      positiony=800;
      da=(-PI/2);
    }
    if (left==true && linbound==true) {
      positionx=70;
      positiony=-100;
      da=(PI/2);
    }
    if (left==false && linbound==false) {
      positionx=1300;
      positiony=800;
      da=(-PI/2);
    }
    if (left==false && linbound== true) {
      positionx=1240;
      positiony=-100;
      da=(PI/2);
    }
    fa=da;
    mc= new movement_data(positionx, positiony, 2.5f, 0, 2.5f, da, 0, fa);
  }
  //calling movement data
  public void allMovement() {
    
    depart();
    mc.movement_master();
    mc.movement();
    
    
    if (leaving==false) {
      intoLot();
      intoRow();
      intoStall();
      }
  }
  //register parking
  public boolean parked() {
    if (mc.velocity==0 && mc.acceleration==0) {
      stopped=true;
      
      
      return true;
    }
    stopped=false;
    return false;
  }
  //turning
  public void intoLot() {
    if (park==true) {
      float turning_pointx=0;
      float turning_pointy=342;
      if (lleft==true && linbound==false) {
        turning_pointx=130;
        turning_pointy=443;
      } else if (lleft==true && linbound==true) {
        turning_pointx=70;
      } else if (lleft==false && linbound==false) {
        turning_pointx=1300;
        turning_pointy=550;
      } else if (lleft==false && linbound== true) {
        turning_pointx=1240;
      }
      if (linbound &&( mc.py<=turning_pointy-100 && mc.py>=turning_pointy-104)) {
        mc.f_velocity=1.3f;
      }
      if (linbound==false && (mc.py>=turning_pointy+100 && mc.py<=turning_pointy+104)) {
        mc.f_velocity=1.3f;
      }
      if (( mc.py<=turning_pointy+1 && mc.py>=turning_pointy-1)&&( mc.px<=turning_pointx+1 && mc.px>=turning_pointx-1)) {
        mc.turn_complete=false;
        if (lleft) {
          mc.f_angle=0;
        } else {
          mc.f_angle=PI;
        }
      }
    }
  }
  public void intoRow() {
    float turningx=185;
    float turningy=390;
    float turningx2=0;
    float turningy2=0;
    if (top) {
      turningx2=234;
      turningy2=243;
      if (( mc.py<=turningy+5 && mc.py>=turningy-5)&&( mc.px<=turningx+5 && mc.px>=turningx-5)) {
        mc.turn_complete=false;
        mc.f_angle=(-PI/2);
      }
      if (( mc.py<=turningy2+3 && mc.py>=turningy2-3)&&( mc.px<=turningx2+5 && mc.px>=turningx2-5)) {
        mc.turn_complete=false;
        mc.f_angle=0;
        if (lstall==0 && lsection==0) {
          mc.defaultFangle=PI/70;
          mc.f_angle=(PI/2);
        }
      }
    } else if (bottom) {
      turningx2=234;
      turningy2=538;
      if (( mc.py<=turningy+5 && mc.py>=turningy-5)&&( mc.px<=turningx+3 && mc.px>=turningx-3)) {
        mc.turn_complete=false;
        mc.f_angle=(PI/2);
      }
      if (( mc.py<=turningy2+3 && mc.py>=turningy2-3)&&( mc.px<=turningx2+3 && mc.px>=turningx2-3)) {
        mc.turn_complete=false;
        mc.f_angle=0;
        if (lstall==5 && lsection==3) {
          mc.defaultFangle=PI/70;
          mc.f_angle=(-PI/2);
        }
      }
    }
    /* rectMode(RADIUS);
     fill(255,255,40);
     rect(turningx2,turningy2,6,6);
     rect(turningx,turningy,6,10);
     rectMode(CORNER); */
  }
  public void intoStall() {
    float turningx=(236+(300*adj_section)+(50*adj_stall));
    float turningy;
    float FinalA;
    float stopx=turningx+50;
    float stopy = 0;
    if (top) {
      turningy=194;
      stopy=turningy+48;
      FinalA=(PI/2);
    } else if (bottom) {
      turningy=586;
      FinalA=(-PI/2);
      stopy=turningy-48;
    } else {
      turningy=391;
      if (lsection==0 || lsection==1 || lsection ==2) {
        FinalA=(-PI/2);
        stopy=turningy-42;
      } else {
        FinalA=(PI/2);
        stopy=turningy+42;
      }
    }
    if (( mc.py<=turningy+5 && mc.py>=turningy-5)&&( mc.px<=turningx+5 && mc.px>=turningx-5)) {
      mc.turn_complete=false;
      mc.f_angle=FinalA;
    }
    if (( mc.py<=stopy+13 && mc.py>=stopy-13)&&( mc.px<=stopx+7 && mc.px>=stopx-7)) {
      mc.f_velocity=0;
    }
  }





/*void depart(){
  float forwardy2=394;
  float right=1166;
  if(leaving){
    if(mc.px<1165){
    mc.px=1165;
    mc.py=394;
    mc.velocity=1.3;
    mc.f_velocity=1.3;
    mc.acceleration=0;
    mc.dirn_angle=0;
    }
 
  if (( mc.py<=forwardy2+2 && mc.py>=forwardy2-2)&&( mc.px<=right+2 && mc.px>=right-2)) {
      mc.turn_complete=false;
      mc.f_angle=(PI/2);
      mc.f_velocity=5;
      }
      } */

  public void depart() {
    if(leaving){
      if(stopped){
      mc.f_velocity=-1.5f;
      mc.f_angle=0;
      //mc.defaultFangle=PI/70;
      mc.turn_complete=false;
      mc.velocity=-1.5f;
      
      }
      float forwardx=(230+(300*adj_section)+(50*adj_stall));
      float forwardy=194;
      float forwardy2=386;
      float forwardy3=585;
      float outx=1090;
      float left=1250;
      float right=1198;
      float exitrx=1135;
      float exitry=340;
      float exitry2=440;
      int LorR=(int)random(2);
      if (( mc.py<=forwardy+15 && mc.py>=forwardy-15)&&( mc.px<=forwardx+5 && mc.px>=forwardx-5)) {
      mc.velocity=0.1f;
      mc.f_velocity=1.3f;
      }
      if (( mc.py<=forwardy2+15 && mc.py>=forwardy2-15)&&( mc.px<=forwardx+5 && mc.px>=forwardx-5)) {
      mc.velocity=0.1f;
      mc.f_velocity=1.3f;
      }
      if (( mc.py<=forwardy3+12 && mc.py>=forwardy3-12)&&( mc.px<=forwardx+5 && mc.px>=forwardx-5)) {
      mc.velocity=0.1f;
      mc.f_velocity=1.3f;
      }
      if (( mc.py<=forwardy+12 && mc.py>=forwardy-12)&&( mc.px<=outx+10 && mc.px>=outx-10)) {
      mc.turn_complete=false;
      mc.f_angle=(PI/2);
      }
      if (( mc.py<=forwardy2+12 && mc.py>=forwardy2-12)&&( mc.px<=outx+10 && mc.px>=outx-10)) {
      mc.turn_complete=false;
      mc.f_angle=0;
      }
      if (( mc.py<=forwardy3+12 && mc.py>=forwardy3-12)&&( mc.px<=outx+10 && mc.px>=outx-10)) {
      mc.turn_complete=false;
      mc.f_angle=(-PI/2);
      }
      if (( mc.py<=exitry2+12 && mc.py>=exitry2-12)&&( mc.px<=exitrx+10 && mc.px>=exitrx-10)) {
      mc.turn_complete=false;
      mc.f_angle=0;
      }
      if (( mc.py<=exitry+12 && mc.py>=exitry-12)&&( mc.px<=exitrx+10 && mc.px>=exitrx-10)) {
      mc.turn_complete=false;
      mc.f_angle=0;
      }
      println(LorR);
      if(LorR==0){
        if (( mc.py<=forwardy2+30 && mc.py>=forwardy2-30)&&( mc.px<=left+8 && mc.px>=left-8)) {
      mc.turn_complete=false;
      mc.f_angle=(-PI/2);
      }
      }
      if(LorR==1){
        if (( mc.py<=forwardy2+30 && mc.py>=forwardy2-30)&&( mc.px<=right+8 && mc.px>=right-8)) {
      mc.turn_complete=false;
      mc.f_angle=(PI/2);
      }
      }
      
     
        
      
      
        
      
    }
  }
    
  




  public void draw_car() {
translate(mc.px,mc.py);
rotate(mc.dirn_angle);

float s=1;
float superS = 0.08f;
scale(superS);
noStroke();
//Tires
fill(0);
//back left
quad(-345*s,-230*s,-195*s,-230*s,-195*s,-145*s,-345*s,-145*s);
ellipse(-195*s,-187.5f*s,30*s,85*s);
ellipse(-345*s,-187.5f*s,30*s,85*s);
//back right
quad(-345*s,145*s,-195*s,145*s,-195*s,230*s,-345*s,230*s); 
ellipse(-195*s,187.5f*s,30*s,85*s);
ellipse(-345*s,187.5f*s,30*s,85*s);

//cool new tires
//front left
pushMatrix();
translate(275*s,-180*s);
rotate(0);
quad(-75*s,42.5f*s,75*s,42.5f*s,75*s,-42.5f*s,-75*s,-42.5f*s);
ellipse(-75*s,0*s,30*s,-85*s);
ellipse(75*s,0*s,30*s,-85*s);
popMatrix();
//front right
pushMatrix();
translate(275*s,180*s);
rotate(0);
quad(-75*s,42.5f*s,75*s,42.5f*s,75*s,-42.5f*s,-75*s,-42.5f*s);
ellipse(-75*s,0*s,30*s,-85*s);
ellipse(75*s,0*s,30*s,-85*s);
popMatrix();

//Body
//lights

fill(0xffFFF81F);
triangle(370*s,-205*s,446*s,-110*s,420*s,-200*s);
triangle(370*s,205*s,446*s,110*s,420*s,200*s);
fill(cc.red,cc.green,cc.blue);
if(fil.night){
pushMatrix();
scale(2);
image(head,200,20);
image(head,200,-130);
popMatrix();
}
//front
ellipse(285*s,-100*s,320*s,250*s);
ellipse(285*s,100*s,320*s,250*s);
quad(300*s,-215*s,300*s,215*s,-300*s,215*s,-300*s,-215*s);
arc(296*s,0*s,330*s,500*s,-(PI/4),(PI/4));
//Back
arc(-235*s,-90*s,600*s,270*s,(5*PI/4)+(PI/20),(7*PI/4));
arc(-235*s,90*s,600*s,270*s,(PI/4),(3*PI/4)-(PI/20));
arc(-95*s,0*s,700*s,900*s,(7*PI/8)-(PI/42),(9*PI/8)+(PI/42));
quad(-407*s,-202*s,-220*s,-202*s,-220*s,202*s,-407*s,202*s);
//mirrors
arc(140*s,-202*s,95*s,110*s,-PI/2,PI/4,OPEN);
arc(140*s,202*s,95*s,110*s,-PI/4,PI/2,OPEN);
fill(255);
image(window,50,-200);
image(engi,-400,-250);
}

class colour {
  float red;
  float green;
  float blue;
  colour(float r, float g, float b) {
    red=r;
    green=g;
    blue=b;
    }
  }
}
class Control {
  Control() {
    setButton();
    setModifyers();
    setCal();
  }
  //car Spawn Freqency
  float carSpawnFreq = .01f;
  //Inbound freq
  float inBoundFreq = 0.5f;
  //West Raod freq
  float westBoundFreq = 0.5f;
  //Parking freq
  float parkingFreq = 0.5f;
  //Cars leaving freqency
  float leaveFreq = 0.4f;
  //Drifting chance
  float driftingFreq = 0.01f;
  //Events
  float eventFreq = 0.01f;
  //Weather
  float weatherFreq = 0.05f;
  /*--------------------------------------------------------------Control Panel Control.... yea-----------------------------------------------------------------------*/
  public void freqRun() {
    carSpawn();
    leave();
    if(CDate.min == 0){
      Wfreq();
    }
    Night();
  }

  public void ControlDraw() {
    fill(0);
    noStroke();
    rect(0, 0, 1500, 150);
    roundVals();
    drawModifyers();
    displayButtion();
    drawCalander();
    drawRates();
    drawInfo();

  }
  public void leave() {
    int X;
    int Y;
    int x;
    int y;
    if (random(1) < leaveFreq) {
      if(Lot.WGate.total!= 60){
        do{
          X = (int)random(3);
          Y = (int)random(2);
          x = (int)random(5);
          y = (int)random(2);
          if(Lot.PS[X][Y].ps[x][y].getOccupided()){
            for(int i = 0; i < Cars.size(); i++){
              if(Cars.get(i).lsection == convertSec(X,Y)&& Cars.get(i).lstall == convertStall(x,y))
              Cars.get(i).leaving = true;
            }
            Calc.SetTime(CDate,Lot.PS[X][Y].ps[x][y].timeTaken);
            Calc.getCost();
            customer++;
            revenue += Calc.getCost();
            Lot.PS[X][Y].ps[x][y].saved = false;
            Lot.PS[X][Y].ps[x][y].res = false;
            Lot.PS[X][Y].ps[x][y].occupied = false;
            break;
          }
        }while(true);
      }
    }
  }
  public void roundVals(){
    carSpawnFreq = (float)round((carSpawnFreq)*1000)/1000;
    inBoundFreq = (float)round((inBoundFreq)*1000)/1000;
    westBoundFreq = (float)round((westBoundFreq)*1000)/1000;
    parkingFreq = (float)round((parkingFreq)*1000)/1000;
    leaveFreq = (float)round((leaveFreq)*1000)/1000;
    driftingFreq = (float)round((driftingFreq)*1000)/1000;
    eventFreq = (float)round((eventFreq)*1000)/1000;
    weatherFreq = (float)round((weatherFreq)*1000)/1000;
    if(carSpawnFreq > 1)
      carSpawnFreq = 1;
    if(inBoundFreq > 1)
      inBoundFreq = 1;
    if(westBoundFreq > 1)
      westBoundFreq = 1;
    if(parkingFreq > 1)
      parkingFreq = 1;
    if(leaveFreq > 1)
      leaveFreq = 1;
    if(driftingFreq > 1)
      driftingFreq = 1;
    if(eventFreq > 1)
      eventFreq = 1;
    if(weatherFreq > 1)
      weatherFreq = 1;
     //
    if(carSpawnFreq < 0)
      carSpawnFreq = 0;
    if(inBoundFreq < 0)
      inBoundFreq = 0;
    if(westBoundFreq < 0)
      westBoundFreq = 0;
    if(parkingFreq < 0)
      parkingFreq = 0;
    if(leaveFreq < 0)
      leaveFreq = 0;
    if(driftingFreq < 0)
      driftingFreq = 0;
    if(eventFreq < 0)
      eventFreq = 0;
    if(weatherFreq < 0)
      weatherFreq = 0;
  }
  /*----------------------------------------------------------------Calander and Rates and Etc--------------------------------------------------------------------------*/
    PImage RainPic;
    PImage SnowPic;
    PImage Clear;
    PImage Day;
    PImage Night;
  public void setCal(){
    RainPic = loadImage("Textures/RainPic.png");
    SnowPic = loadImage("Textures/SnowPic.png");
    Clear = loadImage("Textures/Clear.png");
    Day = loadImage("Textures/Sun.png");
    Night = loadImage("Textures/Moon.png");
  }
  public void calImg(){
    if(fil.snow){
      image(SnowPic,CalanderX,CalanderY);
    }else if(fil.rain){
      image(RainPic,CalanderX,CalanderY);
    }else{
      image(Clear,CalanderX,CalanderY);
    }
    if(isNight){
      image(Night,CalanderX,CalanderY);
    }else
      image(Day,CalanderX,CalanderY);
  }
  final int CalanderX = 1200;
  final int CalanderY = 35;
  public void drawCalander() {
    fill(255);
    text(CDate.toString(), CalanderX, CalanderY - 10);
    rect(CalanderX, CalanderY, 100, 100);
    calImg();
  }
  final String RatesT1 = "Rates By The Day";
  final String RatesT2 = "Monday-Saturday: \n$3 Per hour";
  final String RatesT3 = "Sundays: \n$1.5 Per hour";
  final int RatesX = 750;
  final int RatesY = 35;
  public void drawRates() {
    fill(255);
    rect(RatesX, RatesY, 130, 100);
    fill(0);
    text(RatesT1, RatesX+10, RatesY + 20);
    text(RatesT2, RatesX+10, RatesY + 40); 
    text(RatesT3, RatesX+10, RatesY + 70);
  }
  float revenue = 0;
  int customer = 0;
  final int InfoX = 900;
  final int InfoY = 35;
  public void drawInfo() {
    fill(255);
    rect(InfoX, InfoY, 200, 100);
    fill(0);
    text("Total Revenue: " + revenue, InfoX+10, InfoY + 20);
    text("Days Passed: "  + CDate.day, InfoX+10, InfoY + 40); 
    text("Total Customers: "  + customer, InfoX+10, InfoY + 60);    
    text("Revenue PerDay: "  + (revenue/CDate.day), InfoX+10, InfoY + 80);
  }
  /*----------------------------------------------------------------Modifyers--------------------------------------------------------------*/
  int modX = 4;
  int modY = 3;
  modify[][] mod = new modify[modX][modY];
  public void setModifyers() {
    for (int y =0; y < modY; y++) {
      for (int x = 0; x < modX; x++) {
        mod[x][y] = new modify();
      }
    }
    //MANUTAL ;-;
    mod[0][0].setTitle("Car Spawn Freq");
    mod[0][1].setTitle("In Bound Freq");
    mod[0][2].setTitle("WestBound Freq");
    mod[1][0].setTitle("Parking Freq");
    mod[1][1].setTitle("Leaving Freq");
    mod[1][2].setTitle("Drifting Freq");
    mod[2][0].setTitle("Event Freq");
    mod[2][1].setTitle("Weather Change Freq");
  }
  public void Manual() {
    mod[0][0].setText(String.valueOf(carSpawnFreq));
    mod[0][1].setText(String.valueOf(inBoundFreq));
    mod[0][2].setText(String.valueOf(westBoundFreq));
    mod[1][0].setText(String.valueOf(parkingFreq));
    mod[1][1].setText(String.valueOf(leaveFreq));
    mod[1][2].setText(String.valueOf(driftingFreq));
    mod[2][0].setText(String.valueOf(eventFreq));
    mod[2][1].setText(String.valueOf(weatherFreq));
  }
  public void drawModifyers() {
    Manual();
    for (int y =0; y < modY; y++) {
      for (int x = 0; x < modX; x++) {
        pushMatrix();
        translate(120*x+50, 40*y+30);
        mod[x][y].drawModify();
        popMatrix();
      }
    }
    rectMode(CORNER);
    textAlign(LEFT);
  }
  /*---------------------------------------------------------------------------Car Spawning-----------------------------------------------------------------------------------*/
  public void carSpawn() {
    int X=11;
    int Y=11;
    int x=11;
    int y=11;
    boolean west= false;
    boolean inBound= false;
    boolean parking = false;
    if (random(1) < carSpawnFreq) {
      if (random(1) < inBoundFreq) {
        inBound = true;
      }
      if (random(1) < westBoundFreq) {
        west = true;
        if(Lot.WGate.total != 0 && Lot.getOpen() != 0){
        if (random(1) < parkingFreq && west) {
          parking = true;
            do{
            X = (int)random(3);
            Y = (int)random(2);
            x = (int)random(5);
            y = (int)random(2);
            if(!Lot.PS[X][Y].ps[x][y].getOccupided()&&!Lot.PS[X][Y].ps[x][y].getRes()){
              Lot.PS[X][Y].ps[x][y].res = true;
              break;
            }
          }while(true);
        }
      }
      }
      Cars.add(new Car(west,parking,inBound,convertSec(X,Y),convertStall(x,y)));
    }
  }
  public int convertStall(int x, int y){
    return y*5 + x;
  }
  public int convertSec(int X, int Y){
    return Y*3+X;
  }

  /*------------------------------------------------------------------------Display Buttons-----------------------------------------------------------------*/
  //Pause and play buttons images and if currently playing
  PImage pause;
  PImage play;
  boolean isPlay = false;
  //Button setup (loading images)
  public void setButton() {
    pause = loadImage("Textures/Pause.png");
    play = loadImage("Textures/Play.png");
  }
  int buttX = 635;
  int buttY = 25;
  public void displayButtion() {
    if (!isPlay)
      image(play, buttX, buttY);
    else
      image(pause, buttX, buttY);
  }
  /*------------------------------------------------------------------------Filters controls----------------------------------------------------------------------------*/
  public void Wfreq(){
    if(random(1) < weatherFreq){
      int x = (int)random(3);
      if(x == 0){
        fil.setSnowing(true);
        fil.setRaining(true);
      }else if(x == 1){
        fil.setSnowing(false);
        fil.setRaining(true);
      }else if(x == 2){
        fil.setSnowing(true);
        fil.setRaining(false);
      }
    }
  }
  boolean isNight = true;
  public void Night(){
    if(CDate.min == 0 && CDate.hour == 6){
      if(CDate.before_noon){
        isNight = false;
      }else{
        isNight = true;
      }
      fil.setNighting(isNight);
    }
  }
}
class modify{
  String Text;
  String title;
  modify(){
    title = "Nothing :D";
    Text = "Hi";
  }
  //Sets title and value for the perameter
  modify(String t, String s){
    title = t;
    Text = s;
  }
  public void drawModify() {
    fill(255);
    triangle(0, 0, 10, -10, 10, 10);
    triangle(100, 0, 90, -10, 90, 10);
    rectMode(CORNERS);
    rect(20,-10,80,10);
    //Title
    textAlign(CENTER);
    text(title, 50,-15);
    fill(0);
    text(Text,50,5);
  }
  
  public void setText(String s){
    Text = s;
  }
  public void setTitle(String t){
    title = t;
  }
  
}
class Date {
  final String [] weekDays = {"Monday", "Tuesday", "Wedsday", "Thursday", "Friday", "Saturday", "Sunday"};
  int day;
  int dayOfWeek;
  int hour;
  int min;
  boolean before_noon;
  Date(int D,int h, int m, boolean beforeNoon){
    day = D;
    hour = h;
    min = m;
    dayOfWeek = day%7;
    before_noon = beforeNoon;
    check();
  }
  Date(Date d){
    day = d.day;
    hour = d.hour;
    min = d.min;
    dayOfWeek = d.dayOfWeek;
    before_noon = d.before_noon;
    check();
  }

  public void addHour(){
    hour ++;
    check();
  }
  public void addMin(){
    min ++;
    check();
  }
  
  public void check(){
    //min check
    while(min > 59){
      min -= 60;
      hour++;
    }
    //hours check
    while(hour > 12){
      if(before_noon){
        hour -= 12;
        before_noon = false;
      }else{
        hour -= 12;
        before_noon = true;
        dayOfWeek++;
        day++;
      }
    }
    //day check
    dayOfWeek = day%7;
  }
  //Display
  public String toString(){
   String date = weekDays[dayOfWeek];
   //format hour
   if(hour < 10){
    date += " 0" + hour; 
   }else{
     date += " " + hour;
   }
    
   //format Mintue
   if(min < 10){
     date += ":0" + min;
   }else{
     date += ":" + min;
   }
   
   //formate time of day
   if(before_noon){
     date += " AM";
   }else{
     date += " PM";
   }
   return date;
    
  }
}
class Gate {
  int PosX;
  int PosY;
  boolean isWestGate;
  boolean isOpen;
  int total;
  PImage haz;
  PImage Booth;
  int [][]ava = new int[2][3];
  Gate(int Sx, int Sy, boolean West, boolean State) {
    PosX = Sx;
    PosY = Sy;
    isWestGate = West;
    isOpen = State;
    haz = loadImage("Textures/Hazzard Tape.png");
    Booth = loadImage("Textures/Booth.png");
  }
  public void DrawGate() {
    stroke(1);
    fill(255);
    pushMatrix();
    translate(PosX, PosY);
    rect(0, -37, 25, 25);
    image(Booth, 0, -37);
    if (isWestGate) {
      rect(-27, +43, 55, 180);
      fill(0);
      textAlign(CENTER);
      fill(255,0,0);
      text("Secion1:\n" + ava[0][0]+ "\nSecion2:\n" + ava[0][1] + "\nSecion3:\n" + ava[1][0] + "\nSection4:\n" + ava[1][1] + "\nSection5:\n" + ava[2][0] + "\nSection6:\n" + ava[2][1], -2,60);
      textAlign(LEFT);
    } else {
      rect(+5, +43, 40, 25);
      fill(0);
      float Fee = Calc.getCost();
      text("Fee:\n " + Fee, +6, + 53);
    }
    //Arm Thingy
    float Rotation = 0;
    if (isWestGate) {
      if (total == 0)
        isOpen = false;
      else
        isOpen = true;
    } else {
      if (total == 60) {
        isOpen = false;
      } else
        isOpen = true;
    }
    if (isOpen) {
      Rotation = PI/4;
    }
    if (!isWestGate) {
      Rotation *= -1;
    }
    translate(0, -12);
    rotate(Rotation);
    image(haz, 0, 0);
    popMatrix();
  }
  public void GetAvaliable(int[][] Av) {
    ava =Av;
  }

  public void GetTotal(int t) {
    total = t;
  }
}
class movement_data {
  float px;
  float py;
  float velocity;
  float acceleration;
  float f_velocity;
  float dirn_angle;
  float angular_v;
  float f_angle;
  float defaultFangle=(PI/120);
  boolean turn_complete=true;
  movement_data(float x, float y, float v, float a, float fv, float da, float av, float fa) {
    px=x;
    py=y;
    velocity=v;
    acceleration=a;
    f_velocity=fv;
    dirn_angle=da;
    angular_v=av;
    f_angle=fa;
  }
  public void movement() {
    velocity+=acceleration;
    px+=velocity*cos(dirn_angle);
    py+=velocity*sin(dirn_angle);
    dirn_angle+=angular_v;

    if (velocity<0.1f && velocity>-0.1f) {
      velocity=0;
      acceleration=0;
    }
    if (angular_v!=0) {
      angular_v=0;
    }
  }
  public void movement_master() {
    if (f_velocity<velocity) {
      acceleration=-0.03f;
    } else if (f_velocity>velocity) {
      acceleration=0.03f;
    }

    if (f_angle<dirn_angle) {
      angular_v=(-defaultFangle);
    } else if (f_angle>dirn_angle) {
      angular_v=(defaultFangle);
    }

    if ((dirn_angle<f_angle+(PI/60))&& (dirn_angle>f_angle-(PI/60))) {
      turn_complete=true;
      defaultFangle=(PI/120);
    }
    if (turn_complete) {
      if ((dirn_angle<=(PI/60)) && (dirn_angle>=(-PI/60))) {
        dirn_angle=0;
        f_angle=dirn_angle;
      }
      if ((dirn_angle<=(PI/2)+(PI/60)) && (dirn_angle>=(PI/2)-(PI/60))) {
        dirn_angle=PI/2;
      }
      if ((dirn_angle<=PI+(PI/60)) && (dirn_angle>=PI-(PI/60))) {
        dirn_angle=PI;
      }
      if ((dirn_angle<=(-PI/2)+(PI/60)) && (dirn_angle>=(-PI/2)-(PI/60))) {
        dirn_angle=(-PI/2);
      } 
      f_angle=dirn_angle;
      angular_v=0;
    }
  }
}
class ParkingLot{
       ParkingSection[][] PS = new ParkingSection[3][2];
       int StartLotX;
       int StartLotY;
       Gate WGate;
       Gate EGate;
    //Constuctor
    ParkingLot(int X, int Y){
      StartLotX = X;
      StartLotY = Y;
      EGate = new Gate(StartLotX + 900, StartLotY + 160,false,false);
      WGate = new Gate(StartLotX - 75, StartLotY + 160,true,true);
      for(int x = 0; x< 3; x++){
        for(int y = 0; y < 2; y++){
           PS[x][y] = new ParkingSection(StartLotX+x*300, StartLotY+y*200);
        }
      }
    }
    public void ParkingLotDraw(){
      //Asphalt
      fill(40,43,42);
      strokeWeight(4);
      stroke(255);
      rect(StartLotX-50, StartLotY-50, 950,440);
      //Parking Section itself
       for(int x = 0; x< 3; x++){
        for(int y = 0; y < 2; y++){
          PS[x][y].ParkingSectionDraw();
         }    
       }   
     }
     public void GateDraw(){
              //Gates
       EGate.DrawGate();
       int Occ[][] = GetOcc();
       EGate.GetTotal(total(Occ));
       WGate.GetAvaliable(GetOcc());
       WGate.GetTotal(total(Occ));
       WGate.DrawGate();
     }
   public int[][] GetOcc(){
     int Occ[][] = new int[3][2];
      for(int x = 0; x< 3; x++){
        for(int y = 0; y < 2; y++){
           Occ[x][y] += PS[x][y].GetOcc();
        }
      }
      return Occ;
   }
   public int total(int[][] t){
     int total =0;
         for(int x = 0; x< 3; x++){
        for(int y = 0; y < 2; y++){
            total += t[x][y];
        }
      }
      return total;
   }
    public int getOpen(){
      int open = 0;
        for(int X = 0; X < 3; X++){
          for(int Y = 0; Y < 2; Y++){
            for(int x = 0; x < 5; x++){
              for(int y =0; y < 2; y++){
                if(!PS[X][Y].ps[x][y].res&&!PS[X][Y].ps[x][y].occupied){
                  open++;
                }
              }
            }
          }
        }
        return open;
    }
    
}
class ParkingSection{
    //Starting X and Y position for Stalls
    int StartX;
    int StartY;
    ParkingStall[][] ps = new ParkingStall[5][2];
    //Consturctor
    ParkingSection(int Sx, int Sy){
      StartY = Sy;
      StartX = Sx;
        //Setup ParkingStalls
        for(int x = 0; x< 5; x++){
          for(int y = 0; y < 2; y++){
           ps[x][y] = new ParkingStall((StartX + x* 50), (StartY + y*70));
          }
        }
    }
    
    //Draw
    public void ParkingSectionDraw(){
         for(int x = 0; x< 5; x++){
          for(int y = 0; y < 2; y++){
            ps[x][y].drawStall();
          }
        }
    }
    //Get Num Occupied Stalls
    public int GetOcc(){
     int Occ = 0;
     for(int x = 0; x< 5; x++){
        for(int y = 0; y < 2; y++){
           if(!ps[x][y].getOccupided()){
             Occ++;
           }
        }
     }
     return Occ;
    }
}
class ParkingStall{
  // STALL ATTRIBUTES
  boolean occupied;
  boolean res = false;
  boolean saved = false;
  Date timeTaken;
  
  // DIMENSIONS AND POSITION
  float stallWidth = 50;
  float stallHeight = 70;
  float posX;
  float posY;
  
  ParkingStall(float x, float y) {
    occupied = false;
    res = false;
    posX = x;
    posY = y;
  }

  public boolean getRes(){
    return res;
  }
  public boolean getOccupided(){
    return occupied;
  }
  public void drawStall() {
    
    if (occupied){
      fill(color(255, 90, 71)); // RED STALL
    }
    else if(res){
      fill(255,255,0);//yellow Stall
    }
    else
      fill(color(152, 251, 152));  // GREEN STALL
    strokeWeight(4);
    stroke(255);
    rect(posX, posY, stallWidth, stallHeight);
    strokeWeight(1);
  }
  // Sets whether the stall is occupied or not
  public void setStatus(boolean status, Date time)
  {
    occupied = status;
    if (occupied) {
      timeTaken = new Date(time);
    }
  }
}
class Street_2{
  PImage Street;
  int PosX;
  int PosY;
  Street_2(int X, int Y,String Dir){
    PosX = X;
    PosY = Y;
    Street = loadImage(Dir);
  }
  public void StreetDraw(){
     image(Street,PosX,PosY);
  }


}
class CostCalc{
    int Day;
    int Hour;
    boolean before_noon;
    int SunHours;
    int OtherHours;
    int CalDay;
    int CalHour;
    int CalDayOfWeek;
    boolean CalBefore_Noon;
    float cost = 0.00f;
  public void SetTime(Date C, Date Got){
    cost = 0;
    SunHours = 0;
    OtherHours = 0;
    Day = Got.day;
    Hour = Got.hour;
    before_noon = Got.before_noon;
    CalDay = C.day - Day;
    CalHour = C.hour;
    CalDayOfWeek = C.dayOfWeek;
    CalBefore_Noon = C.before_noon;
    cost = CalcHours();
  }
  public float getCost(){
    return cost;
  }
   public boolean Over(){
     if(CalDay == 0 && Hour == CalHour && CalBefore_Noon == before_noon){
       return false;
     }
     return true;
   }
   public float CalcHours(){
     while(Over()){
       CalHour--;
       //hours
       if(CalDayOfWeek == 6)
         SunHours++;
       else
         OtherHours++;
       if(CalHour == 0){
         CalHour = 12;
         if(CalBefore_Noon){
           CalBefore_Noon = false;
           CalDay--;
           CalDayOfWeek--;
         }else{
           CalBefore_Noon = true;
         }
       }
       if(CalDayOfWeek == -1)
       CalDayOfWeek = 6;
     }
     cost = SunHours * 1.5f + OtherHours * 3;
    return (cost);
   }
}
class filters{
/*-----------------------------------------------------------------------------Back Ground -------------------------------------------------------------------------------*/
  int backR;
  int backG;
  int backB;
  
  public void setBackSnow(){
    backR = 255;
    backG = 255;
    backB = 255;
  
  }
  public void setBackNorm(){
    backR = 31;
    backG = 147;
    backB = 16;
  }
  /*----------------------------------------------------------------Snow Filter---------------------------------------------------------------*/
public void setSnow(){
    for(int x =0; x < 3; x++){
      for(int y =0; y <3 ; y++){
        Snow[x][y] = loadImage("Textures/Snow2.png");
      }
    }
  }
  PImage [][] Snow = new PImage[3][3];
  float disX = 0;
  float disY = 0;
  public void drawSnow(){
    pushMatrix();
    translate(disX,disY);
    for(int x =0; x < 3; x++){
      for(int y =0; y <3 ; y++){
        image(Snow[x][y], -685 + x*685, -350 + y *350);
      }
    }
    popMatrix();
    disX += 685/180;
    disY += 350/180;
    if(disX > 685)
      disX = 0;
    if(disY > 350)
      disY = 0;
  }
  /*------------------------------------------------------------------------------------------Night Filter-------------------------------------------------------------------------------*/
  PImage dark;
  public void setNight(){
     dark = loadImage("Textures/Darkness.png");
  }
  public void drawNight(){
    image(dark,0,DisplaceY);
  }
  
  
  /*--------------------------------------------------------------------------------------------Rain Filter-------------------------------------------------------------------*/
  public void setRain(){
    for(int x =0; x < 3; x++){
      for(int y =0; y <3 ; y++){
        Rain[x][y] = loadImage("Textures/Rain.png");
      }
    }
  }
  PImage [][] Rain = new PImage[3][3];
  float disXR = 0;
  float disYR = 0;
  public void drawRain(){
    pushMatrix();
    translate(disXR,disYR);
    for(int x =0; x < 3; x++){
      for(int y =0; y <3 ; y++){
        image(Rain[x][y], -685 + x*685, -350 + y *350);
      }
    }
    popMatrix();
    disXR += 685/30;
    disYR += 350/30;
    if(disXR > 685)
      disXR = 0;
    if(disYR > 350)
      disYR = 0;
  }
  
  /*-------------------------------------------------------------------------Filter Control--------------------------------------------------------------------*/
  final int DisplaceY = 150;
  //setALl images
  public void setAll(){
    setNight();
    setSnow();
    setRain();
  }
  boolean snow = true;
  boolean night = true;
  boolean rain = false;
  public void curFill(){
    if(snow){
      drawSnow();
      setBackSnow();
    }else
      setBackNorm();
    if(night)
      drawNight();
    if(rain)
      drawRain(); 
  }
  /*---------------------------------------------------------------------------Set Weather-------------------------------------------------------------------------*/
  public void setSnowing(boolean x){
    snow = x;
  }
  public void setRaining(boolean x){
    rain = x;
  }
  public void setNighting(boolean x){
    night = x;
  }

}
  public void settings() {  size(1370, 700); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "FinalProjectMain" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
